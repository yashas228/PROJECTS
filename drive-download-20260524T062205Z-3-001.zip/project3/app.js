const sportsData = {
    football: [
      {
            id: 'epl_expanded', name: 'English Football (Expanded)', desc: 'Top-tier and historic English clubs.',
            teams: [
                { id: 'arsenal', name: 'Arsenal', rank: 1, desc: 'North London Giants.', players: [
                    { name: 'Bukayo Saka', stats: 'FW' }, { name: 'Martin Ødegaard', stats: 'MF' }, { name: 'Declan Rice', stats: 'MF' },
                    { name: 'William Saliba', stats: 'DF' }, { name: 'Gabriel Magalhães', stats: 'DF' }, { name: 'David Raya', stats: 'GK' },
                    { name: 'Kai Havertz', stats: 'FW' }, { name: 'Gabriel Martinelli', stats: 'FW' }, { name: 'Ben White', stats: 'DF' },
                    { name: 'Mikel Merino', stats: 'MF' }, { name: 'Riccardo Calafiori', stats: 'DF' }, { name: 'Jurriën Timber', stats: 'DF' }
                ]},
                { id: 'astonvilla', name: 'Aston Villa', rank: 2, desc: 'Birmingham powerhouse.', players: [
                    { name: 'Emiliano Martínez', stats: 'GK' }, { name: 'Ollie Watkins', stats: 'FW' }, { name: 'John McGinn', stats: 'MF' },
                    { name: 'Pau Torres', stats: 'DF' }, { name: 'Amadou Onana', stats: 'MF' }, { name: 'Leon Bailey', stats: 'FW' },
                    { name: 'Ezri Konsa', stats: 'DF' }, { name: 'Youri Tielemans', stats: 'MF' }, { name: 'Morgan Rogers', stats: 'FW' },
                    { name: 'Matty Cash', stats: 'DF' }, { name: 'Jacob Ramsey', stats: 'MF' }, { name: 'Jhon Durán', stats: 'FW' }
                ]},
                { id: 'brentford', name: 'Brentford', rank: 3, desc: 'The Bees.', players: [
                    { name: 'Bryan Mbeumo', stats: 'FW' }, { name: 'Yoane Wissa', stats: 'FW' }, { name: 'Christian Nørgaard', stats: 'MF' },
                    { name: 'Ethan Pinnock', stats: 'DF' }, { name: 'Mark Flekken', stats: 'GK' }, { name: 'Mathias Jensen', stats: 'MF' },
                    { name: 'Nathan Collins', stats: 'DF' }, { name: 'Vitaly Janelt', stats: 'MF' }, { name: 'Fábio Carvalho', stats: 'MF' },
                    { name: 'Kevin Schade', stats: 'FW' }, { name: 'Rico Henry', stats: 'DF' }, { name: 'Mikkel Damsgaard', stats: 'MF' }
                ]},
                { id: 'brighton', name: 'Brighton & Hove Albion', rank: 4, desc: 'The Seagulls.', players: [
                    { name: 'Kaoru Mitoma', stats: 'FW' }, { name: 'João Pedro', stats: 'FW' }, { name: 'Lewis Dunk', stats: 'DF' },
                    { name: 'Bart Verbruggen', stats: 'GK' }, { name: 'Danny Welbeck', stats: 'FW' }, { name: 'Simon Adingra', stats: 'FW' },
                    { name: 'Pervis Estupiñán', stats: 'DF' }, { name: 'Carlos Baleba', stats: 'MF' }, { name: 'Georginio Rutter', stats: 'FW' },
                    { name: 'Mats Wieffer', stats: 'MF' }, { name: 'Evan Ferguson', stats: 'FW' }, { name: 'Jan Paul van Hecke', stats: 'DF' }
                ]},
                { id: 'burnley', name: 'Burnley', rank: 5, desc: 'The Clarets.', players: [
                    { name: 'James Trafford', stats: 'GK' }, { name: 'Josh Brownhill', stats: 'MF' }, { name: 'Lyle Foster', stats: 'FW' },
                    { name: 'Luca Koleosho', stats: 'FW' }, { name: 'Maxime Estève', stats: 'DF' }, { name: 'Jordan Beyer', stats: 'DF' },
                    { name: 'Han-Noah Massengo', stats: 'MF' }, { name: 'Zian Flemming', stats: 'MF' }, { name: 'Jérémy Sarmiento', stats: 'FW' },
                    { name: 'Bashir Humphreys', stats: 'DF' }, { name: 'Hannibal Mejbri', stats: 'MF' }, { name: 'Connor Roberts', stats: 'DF' }
                ]},
                { id: 'chelsea', name: 'Chelsea', rank: 6, desc: 'The Blues.', players: [
                    { name: 'Cole Palmer', stats: 'MF' }, { name: 'Enzo Fernández', stats: 'MF' }, { name: 'Moisés Caicedo', stats: 'MF' },
                    { name: 'Reece James', stats: 'DF' }, { name: 'Nicolas Jackson', stats: 'FW' }, { name: 'Levi Colwill', stats: 'DF' },
                    { name: 'Robert Sánchez', stats: 'GK' }, { name: 'Pedro Neto', stats: 'FW' }, { name: 'João Félix', stats: 'FW' },
                    { name: 'Malo Gusto', stats: 'DF' }, { name: 'Noni Madueke', stats: 'FW' }, { name: 'Christopher Nkunku', stats: 'FW' }
                ]},
                { id: 'crystalpalace', name: 'Crystal Palace', rank: 7, desc: 'The Eagles.', players: [
                    { name: 'Eberechi Eze', stats: 'MF' }, { name: 'Jean-Philippe Mateta', stats: 'FW' }, { name: 'Marc Guéhi', stats: 'DF' },
                    { name: 'Dean Henderson', stats: 'GK' }, { name: 'Adam Wharton', stats: 'MF' }, { name: 'Tyrick Mitchell', stats: 'DF' },
                    { name: 'Jefferson Lerma', stats: 'MF' }, { name: 'Daniel Muñoz', stats: 'DF' }, { name: 'Eddie Nketiah', stats: 'FW' },
                    { name: 'Trevoh Chalobah', stats: 'DF' }, { name: 'Cheick Doucouré', stats: 'MF' }, { name: 'Ismaïla Sarr', stats: 'FW' }
                ]},
                { id: 'everton', name: 'Everton', rank: 8, desc: 'The Toffees.', players: [
                    { name: 'Jordan Pickford', stats: 'GK' }, { name: 'Jarrad Branthwaite', stats: 'DF' }, { name: 'James Tarkowski', stats: 'DF' },
                    { name: 'Dwight McNeil', stats: 'MF' }, { name: 'Dominic Calvert-Lewin', stats: 'FW' }, { name: 'Abdoulaye Doucouré', stats: 'MF' },
                    { name: 'Vitaliy Mykolenko', stats: 'DF' }, { name: 'Idrissa Gueye', stats: 'MF' }, { name: 'Jack Harrison', stats: 'FW' },
                    { name: 'Iliman Ndiaye', stats: 'FW' }, { name: 'Jesper Lindstrøm', stats: 'MF' }, { name: 'Nathan Patterson', stats: 'DF' }
                ]},
                { id: 'fulham', name: 'Fulham', rank: 9, desc: 'The Cottagers.', players: [
                    { name: 'Bernd Leno', stats: 'GK' }, { name: 'Antonee Robinson', stats: 'DF' }, { name: 'Andreas Pereira', stats: 'MF' },
                    { name: 'Emile Smith Rowe', stats: 'MF' }, { name: 'Alex Iwobi', stats: 'MF' }, { name: 'Raúl Jiménez', stats: 'FW' },
                    { name: 'Joachim Andersen', stats: 'DF' }, { name: 'Calvin Bassey', stats: 'DF' }, { name: 'Saša Lukić', stats: 'MF' },
                    { name: 'Adama Traoré', stats: 'FW' }, { name: 'Sander Berge', stats: 'MF' }, { name: 'Rodrigo Muniz', stats: 'FW' }
                ]},
                { id: 'leeds', name: 'Leeds United', rank: 10, desc: 'The Whites.', players: [
                    { name: 'Illan Meslier', stats: 'GK' }, { name: 'Ethan Ampadu', stats: 'MF' }, { name: 'Daniel James', stats: 'FW' },
                    { name: 'Wilfried Gnonto', stats: 'FW' }, { name: 'Pascal Struijk', stats: 'DF' }, { name: 'Ilia Gruev', stats: 'MF' },
                    { name: 'Mateo Joseph', stats: 'FW' }, { name: 'Junior Firpo', stats: 'DF' }, { name: 'Largie Ramazani', stats: 'FW' },
                    { name: 'Joe Rodon', stats: 'DF' }, { name: 'Brenden Aaronson', stats: 'MF' }, { name: 'Manor Solomon', stats: 'FW' }
                ]},
                { id: 'liverpool', name: 'Liverpool', rank: 11, desc: 'The Reds.', players: [
                    { name: 'Mohamed Salah', stats: 'FW' }, { name: 'Virgil van Dijk', stats: 'DF' }, { name: 'Trent Alexander-Arnold', stats: 'DF' },
                    { name: 'Alisson Becker', stats: 'GK' }, { name: 'Alexis Mac Allister', stats: 'MF' }, { name: 'Luis Díaz', stats: 'FW' },
                    { name: 'Dominik Szoboszlai', stats: 'MF' }, { name: 'Diogo Jota', stats: 'FW' }, { name: 'Cody Gakpo', stats: 'FW' },
                    { name: 'Ryan Gravenberch', stats: 'MF' }, { name: 'Andrew Robertson', stats: 'DF' }, { name: 'Darwin Núñez', stats: 'FW' }
                ]},
                { id: 'mancity', name: 'Manchester City', rank: 12, desc: 'The Citizens.', players: [
                    { name: 'Erling Haaland', stats: 'FW' }, { name: 'Kevin De Bruyne', stats: 'MF' }, { name: 'Phil Foden', stats: 'MF' }, 
                    { name: 'Rodri', stats: 'MF' }, { name: 'Bernardo Silva', stats: 'MF' }, { name: 'Ruben Dias', stats: 'DF' }, 
                    { name: 'Ederson', stats: 'GK' }, { name: 'Kyle Walker', stats: 'DF' }, { name: 'John Stones', stats: 'DF' }, 
                    { name: 'Josko Gvardiol', stats: 'DF' }, { name: 'Jeremy Doku', stats: 'FW' }, { name: 'Savinho', stats: 'FW' }
                ]},
                { id: 'manutd', name: 'Manchester United', rank: 13, desc: 'Red Devils.', players: [
                    { name: 'Bruno Fernandes', stats: 'MF' }, { name: 'Marcus Rashford', stats: 'FW' }, { name: 'Kobbie Mainoo', stats: 'MF' },
                    { name: 'Lisandro Martínez', stats: 'DF' }, { name: 'André Onana', stats: 'GK' }, { name: 'Alejandro Garnacho', stats: 'FW' },
                    { name: 'Rasmus Højlund', stats: 'FW' }, { name: 'Diogo Dalot', stats: 'DF' }, { name: 'Matthijs de Ligt', stats: 'DF' },
                    { name: 'Joshua Zirkzee', stats: 'FW' }, { name: 'Manuel Ugarte', stats: 'MF' }, { name: 'Luke Shaw', stats: 'DF' }
                ]},
                { id: 'newcastle', name: 'Newcastle United', rank: 14, desc: 'The Magpies.', players: [
                    { name: 'Alexander Isak', stats: 'FW' }, { name: 'Bruno Guimarães', stats: 'MF' }, { name: 'Anthony Gordon', stats: 'FW' },
                    { name: 'Sven Botman', stats: 'DF' }, { name: 'Nick Pope', stats: 'GK' }, { name: 'Joelinton', stats: 'MF' },
                    { name: 'Kieran Trippier', stats: 'DF' }, { name: 'Fabian Schär', stats: 'DF' }, { name: 'Harvey Barnes', stats: 'FW' },
                    { name: 'Sandro Tonali', stats: 'MF' }, { name: 'Dan Burn', stats: 'DF' }, { name: 'Joe Willock', stats: 'MF' }
                ]},
                { id: 'nottmforest', name: 'Nottingham Forest', rank: 15, desc: 'Tricky Trees.', players: [
                    { name: 'Morgan Gibbs-White', stats: 'MF' }, { name: 'Chris Wood', stats: 'FW' }, { name: 'Callum Hudson-Odoi', stats: 'FW' },
                    { name: 'Murillo', stats: 'DF' }, { name: 'Matz Sels', stats: 'GK' }, { name: 'Ryan Yates', stats: 'MF' },
                    { name: 'Anthony Elanga', stats: 'FW' }, { name: 'Neco Williams', stats: 'DF' }, { name: 'Nikola Milenković', stats: 'DF' },
                    { name: 'Elliot Anderson', stats: 'MF' }, { name: 'Ola Aina', stats: 'DF' }, { name: 'Ibrahim Sangaré', stats: 'MF' }
                ]},
                { id: 'sunderland', name: 'Sunderland', rank: 16, desc: 'The Black Cats.', players: [
                    { name: 'Anthony Patterson', stats: 'GK' }, { name: 'Dan Neil', stats: 'MF' }, { name: 'Jobe Bellingham', stats: 'MF' },
                    { name: 'Trai Hume', stats: 'DF' }, { name: 'Luke O\'Nien', stats: 'DF' }, { name: 'Patrick Roberts', stats: 'FW' },
                    { name: 'Chris Rigg', stats: 'MF' }, { name: 'Dennis Cirkin', stats: 'DF' }, { name: 'Romaine Mundle', stats: 'FW' },
                    { name: 'Eliezer Mayenda', stats: 'FW' }, { name: 'Aji Alese', stats: 'DF' }, { name: 'Alan Browne', stats: 'MF' }
                ]},
                { id: 'tottenham', name: 'Tottenham Hotspur', rank: 17, desc: 'Spurs.', players: [
                    { name: 'Son Heung-min', stats: 'FW' }, { name: 'James Maddison', stats: 'MF' }, { name: 'Cristian Romero', stats: 'DF' },
                    { name: 'Guglielmo Vicario', stats: 'GK' }, { name: 'Pedro Porro', stats: 'DF' }, { name: 'Micky van de Ven', stats: 'DF' },
                    { name: 'Dejan Kulusevski', stats: 'MF' }, { name: 'Brennan Johnson', stats: 'FW' }, { name: 'Dominic Solanke', stats: 'FW' },
                    { name: 'Destiny Udogie', stats: 'DF' }, { name: 'Pape Matar Sarr', stats: 'MF' }, { name: 'Yves Bissouma', stats: 'MF' }
                ]},
                { id: 'westham', name: 'West Ham United', rank: 18, desc: 'The Hammers.', players: [
                    { name: 'Jarrod Bowen', stats: 'FW' }, { name: 'Mohammed Kudus', stats: 'FW' }, { name: 'Lucas Paquetá', stats: 'MF' },
                    { name: 'Edson Álvarez', stats: 'MF' }, { name: 'Alphonse Areola', stats: 'GK' }, { name: 'Max Kilman', stats: 'DF' },
                    { name: 'Aaron Wan-Bissaka', stats: 'DF' }, { name: 'Emerson Palmieri', stats: 'DF' }, { name: 'Niclas Füllkrug', stats: 'FW' },
                    { name: 'Tomáš Souček', stats: 'MF' }, { name: 'Jean-Clair Todibo', stats: 'DF' }, { name: 'Michail Antonio', stats: 'FW' }
                ]},
                { id: 'wolves', name: 'Wolverhampton Wanderers', rank: 19, desc: 'Wolves.', players: [
                    { name: 'Matheus Cunha', stats: 'FW' }, { name: 'Hwang Hee-chan', stats: 'FW' }, { name: 'Mario Lemina', stats: 'MF' },
                    { name: 'João Gomes', stats: 'MF' }, { name: 'Nélson Semedo', stats: 'DF' }, { name: 'Rayan Aït-Nouri', stats: 'DF' },
                    { name: 'José Sá', stats: 'GK' }, { name: 'Craig Dawson', stats: 'DF' }, { name: 'Jørgen Strand Larsen', stats: 'FW' },
                    { name: 'Toti Gomes', stats: 'DF' }, { name: 'Jean-Ricner Bellegarde', stats: 'MF' }, { name: 'Sam Johnstone', stats: 'GK' }
                ]}
            ]
        },
        {
            id: 'seriea', name: 'Serie A (Italy)', desc: 'Il massimo campionato di calcio italiano (20 Squadre).',
            teams: [
                { id: 'inter', name: 'Inter Milan', rank: 1, desc: 'I Nerazzurri. Campioni in carica.', players: [
                    { name: 'Lautaro Martínez', stats: 'FW' }, { name: 'Nicolò Barella', stats: 'MF' }, { name: 'Hakan Çalhanoğlu', stats: 'MF' },
                    { name: 'Alessandro Bastoni', stats: 'DF' }, { name: 'Yann Sommer', stats: 'GK' }, { name: 'Marcus Thuram', stats: 'FW' },
                    { name: 'Federico Dimarco', stats: 'DF' }, { name: 'Henrikh Mkhitaryan', stats: 'MF' }, { name: 'Benjamin Pavard', stats: 'DF' },
                    { name: 'Matteo Darmian', stats: 'DF' }, { name: 'Davide Frattesi', stats: 'MF' }, { name: 'Stefan de Vrij', stats: 'DF' }
                ]},
                { id: 'acmilan', name: 'AC Milan', rank: 2, desc: 'I Rossoneri.', players: [
                    { name: 'Rafael Leão', stats: 'FW' }, { name: 'Christian Pulisic', stats: 'FW' }, { name: 'Theo Hernández', stats: 'DF' },
                    { name: 'Mike Maignan', stats: 'GK' }, { name: 'Fikayo Tomori', stats: 'DF' }, { name: 'Tijjani Reijnders', stats: 'MF' },
                    { name: 'Álvaro Morata', stats: 'FW' }, { name: 'Youssouf Fofana', stats: 'MF' }, { name: 'Strahinja Pavlović', stats: 'DF' },
                    { name: 'Ruben Loftus-Cheek', stats: 'MF' }, { name: 'Davide Calabria', stats: 'DF' }, { name: 'Samuel Chukwueze', stats: 'FW' }
                ]},
                { id: 'juventus', name: 'Juventus', rank: 3, desc: 'I Bianconeri.', players: [
                    { name: 'Dušan Vlahović', stats: 'FW' }, { name: 'Gleison Bremer', stats: 'DF' }, { name: 'Teun Koopmeiners', stats: 'MF' },
                    { name: 'Michele Di Gregorio', stats: 'GK' }, { name: 'Kenan Yıldız', stats: 'FW' }, { name: 'Douglas Luiz', stats: 'MF' },
                    { name: 'Andrea Cambiaso', stats: 'DF' }, { name: 'Manuel Locatelli', stats: 'MF' }, { name: 'Federico Gatti', stats: 'DF' },
                    { name: 'Pierre Kalulu', stats: 'DF' }, { name: 'Francisco Conceição', stats: 'FW' }, { name: 'Weston McKennie', stats: 'MF' }
                ]},
                { id: 'atalanta', name: 'Atalanta', rank: 4, desc: 'La Dea.', players: [
                    { name: 'Ademola Lookman', stats: 'FW' }, { name: 'Mateo Retegui', stats: 'FW' }, { name: 'Charles De Ketelaere', stats: 'FW' },
                    { name: 'Éderson', stats: 'MF' }, { name: 'Mario Pašalić', stats: 'MF' }, { name: 'Isak Hien', stats: 'DF' },
                    { name: 'Marco Carnesecchi', stats: 'GK' }, { name: 'Raoul Bellanova', stats: 'DF' }, { name: 'Matteo Ruggeri', stats: 'DF' },
                    { name: 'Berat Djimsiti', stats: 'DF' }, { name: 'Lazar Samardžić', stats: 'MF' }, { name: 'Nicolò Zaniolo', stats: 'FW' }
                ]},
                { id: 'bologna', name: 'Bologna', rank: 5, desc: 'I Rossoblu.', players: [
                    { name: 'Riccardo Orsolini', stats: 'FW' }, { name: 'Remo Freuler', stats: 'MF' }, { name: 'Łukasz Skorupski', stats: 'GK' },
                    { name: 'Sam Beukema', stats: 'DF' }, { name: 'Dan Ndoye', stats: 'FW' }, { name: 'Santiago Castro', stats: 'FW' },
                    { name: 'Stefan Posch', stats: 'DF' }, { name: 'Jhon Lucumí', stats: 'DF' }, { name: 'Giovanni Fabbian', stats: 'MF' },
                    { name: 'Nikola Moro', stats: 'MF' }, { name: 'Thijs Dallinga', stats: 'FW' }, { name: 'Juan Miranda', stats: 'DF' }
                ]},
                { id: 'roma', name: 'AS Roma', rank: 6, desc: 'I Giallorossi.', players: [
                    { name: 'Paulo Dybala', stats: 'FW' }, { name: 'Lorenzo Pellegrini', stats: 'MF' }, { name: 'Artem Dovbyk', stats: 'FW' },
                    { name: 'Gianluca Mancini', stats: 'DF' }, { name: 'Mile Svilar', stats: 'GK' }, { name: 'Evan Ndicka', stats: 'DF' },
                    { name: 'Bryan Cristante', stats: 'MF' }, { name: 'Angeliño', stats: 'DF' }, { name: 'Zeki Çelik', stats: 'DF' },
                    { name: 'Manu Koné', stats: 'MF' }, { name: 'Matías Soulé', stats: 'FW' }, { name: 'Stephan El Shaarawy', stats: 'FW' }
                ]},
                { id: 'lazio', name: 'Lazio', rank: 7, desc: 'I Biancocelesti.', players: [
                    { name: 'Mattia Zaccagni', stats: 'FW' }, { name: 'Alessio Romagnoli', stats: 'DF' }, { name: 'Ivan Provedel', stats: 'GK' },
                    { name: 'Matteo Guendouzi', stats: 'MF' }, { name: 'Valentín Castellanos', stats: 'FW' }, { name: 'Nicolò Rovella', stats: 'MF' },
                    { name: 'Manuel Lazzari', stats: 'DF' }, { name: 'Boulaye Dia', stats: 'FW' }, { name: 'Mario Gila', stats: 'DF' },
                    { name: 'Nuno Tavares', stats: 'DF' }, { name: 'Matías Vecino', stats: 'MF' }, { name: 'Gustav Isaksen', stats: 'FW' }
                ]},
                { id: 'fiorentina', name: 'Fiorentina', rank: 8, desc: 'La Viola.', players: [
                    { name: 'Moise Kean', stats: 'FW' }, { name: 'Albert Guðmundsson', stats: 'FW' }, { name: 'Lucas Martínez Quarta', stats: 'DF' },
                    { name: 'David de Gea', stats: 'GK' }, { name: 'Dodô', stats: 'DF' }, { name: 'Cristiano Biraghi', stats: 'DF' },
                    { name: 'Edoardo Bove', stats: 'MF' }, { name: 'Andrea Colpani', stats: 'MF' }, { name: 'Rolando Mandragora', stats: 'MF' },
                    { name: 'Marin Pongračić', stats: 'DF' }, { name: 'Robin Gosens', stats: 'DF' }, { name: 'Jonathan Ikoné', stats: 'FW' }
                ]},
                { id: 'napoli', name: 'Napoli', rank: 9, desc: 'Gli Azzurri.', players: [
                    { name: 'Khvicha Kvaratskhelia', stats: 'FW' }, { name: 'Romelu Lukaku', stats: 'FW' }, { name: 'Giovanni Di Lorenzo', stats: 'DF' },
                    { name: 'Amir Rrahmani', stats: 'DF' }, { name: 'Alex Meret', stats: 'GK' }, { name: 'André-Frank Zambo Anguissa', stats: 'MF' },
                    { name: 'Stanislav Lobotka', stats: 'MF' }, { name: 'Alessandro Buongiorno', stats: 'DF' }, { name: 'Scott McTominay', stats: 'MF' },
                    { name: 'Matteo Politano', stats: 'FW' }, { name: 'Mathías Olivera', stats: 'DF' }, { name: 'David Neres', stats: 'FW' }
                ]},
                { id: 'torino', name: 'Torino', rank: 10, desc: 'Il Toro.', players: [
                    { name: 'Duván Zapata', stats: 'FW' }, { name: 'Antonio Sanabria', stats: 'FW' }, { name: 'Samuele Ricci', stats: 'MF' },
                    { name: 'Vanja Milinković-Savić', stats: 'GK' }, { name: 'Ivan Ilić', stats: 'MF' }, { name: 'Nikola Vlašić', stats: 'MF' },
                    { name: 'Valentino Lazaro', stats: 'DF' }, { name: 'Saúl Coco', stats: 'DF' }, { name: 'Adam Masina', stats: 'DF' },
                    { name: 'Karol Linetty', stats: 'MF' }, { name: 'Ché Adams', stats: 'FW' }, { name: 'Adrien Tameze', stats: 'MF' }
                ]},
                { id: 'genoa', name: 'Genoa', rank: 11, desc: 'Il Grifone.', players: [
                    { name: 'Andrea Pinamonti', stats: 'FW' }, { name: 'Morten Frendrup', stats: 'MF' }, { name: 'Milan Badelj', stats: 'MF' },
                    { name: 'Johan Vásquez', stats: 'DF' }, { name: 'Mattia Bani', stats: 'DF' }, { name: 'Koni De Winter', stats: 'DF' },
                    { name: 'Aarón Martín', stats: 'DF' }, { name: 'Pierluigi Gollini', stats: 'GK' }, { name: 'Junior Messias', stats: 'MF' },
                    { name: 'Vitinha', stats: 'FW' }, { name: 'Morten Thorsby', stats: 'MF' }, { name: 'Stefano Sabelli', stats: 'DF' }
                ]},
                { id: 'monza', name: 'Monza', rank: 12, desc: 'I Brianzoli.', players: [
                    { name: 'Matteo Pessina', stats: 'MF' }, { name: 'Dany Mota', stats: 'FW' }, { name: 'Pablo Marí', stats: 'DF' },
                    { name: 'Giorgos Kyriakopoulos', stats: 'DF' }, { name: 'Stefano Turati', stats: 'GK' }, { name: 'Warren Bondo', stats: 'MF' },
                    { name: 'Daniel Maldini', stats: 'MF' }, { name: 'Armando Izzo', stats: 'DF' }, { name: 'Andrea Carboni', stats: 'DF' },
                    { name: 'Milan Đurić', stats: 'FW' }, { name: 'Alessandro Bianco', stats: 'MF' }, { name: 'Gianluca Caprari', stats: 'FW' }
                ]},
                { id: 'lecce', name: 'Lecce', rank: 13, desc: 'I Salentini.', players: [
                    { name: 'Nikola Krstović', stats: 'FW' }, { name: 'Federico Baschirotto', stats: 'DF' }, { name: 'Wladimiro Falcone', stats: 'GK' },
                    { name: 'Ylber Ramadani', stats: 'MF' }, { name: 'Patrick Dorgu', stats: 'DF' }, { name: 'Antonino Gallo', stats: 'DF' },
                    { name: 'Kialonda Gaspar', stats: 'DF' }, { name: 'Rémi Oudin', stats: 'MF' }, { name: 'Lameck Banda', stats: 'FW' },
                    { name: 'Balthazar Pierret', stats: 'MF' }, { name: 'Hamza Rafia', stats: 'MF' }, { name: 'Frédéric Guilbert', stats: 'DF' }
                ]},
                { id: 'empoli', name: 'Empoli', rank: 14, desc: 'Gli Azzurri.', players: [
                    { name: 'Lorenzo Colombo', stats: 'FW' }, { name: 'Jacopo Fazzini', stats: 'MF' }, { name: 'Giuseppe Pezzella', stats: 'DF' },
                    { name: 'Ardian Ismajli', stats: 'DF' }, { name: 'Devis Vásquez', stats: 'GK' }, { name: 'Emmanuel Gyasi', stats: 'MF' },
                    { name: 'Liam Henderson', stats: 'MF' }, { name: 'Alberto Grassi', stats: 'MF' }, { name: 'Mattia Viti', stats: 'DF' },
                    { name: 'Sebastiano Esposito', stats: 'FW' }, { name: 'Saba Goglichidze', stats: 'DF' }, { name: 'Youssef Maleh', stats: 'MF' }
                ]},
                { id: 'udinese', name: 'Udinese', rank: 15, desc: 'I Friulani.', players: [
                    { name: 'Florian Thauvin', stats: 'FW' }, { name: 'Lorenzo Lucca', stats: 'FW' }, { name: 'Jaka Bijol', stats: 'DF' },
                    { name: 'Maduka Okoye', stats: 'GK' }, { name: 'Sandi Lovrić', stats: 'MF' }, { name: 'Jesper Karlström', stats: 'MF' },
                    { name: 'Hassane Kamara', stats: 'DF' }, { name: 'Kingsley Ehizibue', stats: 'DF' }, { name: 'Lautaro Giannetti', stats: 'DF' },
                    { name: 'Martín Payero', stats: 'MF' }, { name: 'Jordan Zemura', stats: 'DF' }, { name: 'Brenner', stats: 'FW' }
                ]},
                { id: 'cagliari', name: 'Cagliari', rank: 16, desc: 'Gli Isolani.', players: [
                    { name: 'Roberto Piccoli', stats: 'FW' }, { name: 'Zito Luvumbo', stats: 'FW' }, { name: 'Yerry Mina', stats: 'DF' },
                    { name: 'Simone Scuffet', stats: 'GK' }, { name: 'Răzvan Marin', stats: 'MF' }, { name: 'Antoine Makoumbou', stats: 'MF' },
                    { name: 'Tommaso Augello', stats: 'DF' }, { name: 'Gabriele Zappa', stats: 'DF' }, { name: 'Sebastiano Luperto', stats: 'DF' },
                    { name: 'Gianluca Gaetano', stats: 'MF' }, { name: 'Alessandro Deiola', stats: 'MF' }, { name: 'Nicolas Viola', stats: 'MF' }
                ]},
                { id: 'verona', name: 'Hellas Verona', rank: 17, desc: 'I Gialloblu.', players: [
                    { name: 'Casper Tengstedt', stats: 'FW' }, { name: 'Darko Lazović', stats: 'MF' }, { name: 'Lorenzo Montipò', stats: 'GK' },
                    { name: 'Paweł Dawidowicz', stats: 'DF' }, { name: 'Ondrej Duda', stats: 'MF' }, { name: 'Suat Serdar', stats: 'MF' },
                    { name: 'Jackson Tchatchoua', stats: 'DF' }, { name: 'Diego Coppola', stats: 'DF' }, { name: 'Martin Frese', stats: 'DF' },
                    { name: 'Tomáš Suslov', stats: 'MF' }, { name: 'Grigoris Kastanos', stats: 'MF' }, { name: 'Giangiacomo Magnani', stats: 'DF' }
                ]},
                { id: 'como', name: 'Como', rank: 18, desc: 'I Lariani.', players: [
                    { name: 'Patrick Cutrone', stats: 'FW' }, { name: 'Andrea Belotti', stats: 'FW' }, { name: 'Nico Paz', stats: 'MF' },
                    { name: 'Alieu Fadera', stats: 'FW' }, { name: 'Emil Audero', stats: 'GK' }, { name: 'Alberto Dossena', stats: 'DF' },
                    { name: 'Alberto Moreno', stats: 'DF' }, { name: 'Sergi Roberto', stats: 'MF' }, { name: 'Gabriel Strefezza', stats: 'FW' },
                    { name: 'Marc-Oliver Kempf', stats: 'DF' }, { name: 'Máximo Perrone', stats: 'MF' }, { name: 'Ignace Van der Brempt', stats: 'DF' }
                ]},
                { id: 'parma', name: 'Parma', rank: 19, desc: 'I Crociati.', players: [
                    { name: 'Dennis Man', stats: 'FW' }, { name: 'Adrián Bernabé', stats: 'MF' }, { name: 'Zion Suzuki', stats: 'GK' },
                    { name: 'Enrico Delprato', stats: 'DF' }, { name: 'Botond Balogh', stats: 'DF' }, { name: 'Emanuele Valeri', stats: 'DF' },
                    { name: 'Simon Sohm', stats: 'MF' }, { name: 'Hernani', stats: 'MF' }, { name: 'Valentin Mihăilă', stats: 'FW' },
                    { name: 'Ange-Yoan Bonny', stats: 'FW' }, { name: 'Matteo Cancellieri', stats: 'FW' }, { name: 'Woyo Coulibaly', stats: 'DF' }
                ]},
                { id: 'venezia', name: 'Venezia', rank: 20, desc: 'I Lagunari.', players: [
                    { name: 'Joel Pohjanpalo', stats: 'FW' }, { name: 'Gaetano Oristanio', stats: 'FW' }, { name: 'Jesse Joronen', stats: 'GK' },
                    { name: 'Jay Idzes', stats: 'DF' }, { name: 'Michael Svoboda', stats: 'DF' }, { name: 'Francesco Zampano', stats: 'DF' },
                    { name: 'Alfred Duncan', stats: 'MF' }, { name: 'Hans Nicolussi Caviglia', stats: 'MF' }, { name: 'Gianluca Busio', stats: 'MF' },
                    { name: 'Mikael Egill Ellertsson', stats: 'MF' }, { name: 'Ridgeciano Haps', stats: 'DF' }, { name: 'Antonio Candela', stats: 'DF' }
                ]}
            ]
        },
       {
            id: 'ligue1', name: 'Ligue 1 (France)', desc: 'The top professional football league in France (18 Teams).',
            teams: [
                { id: 'psg', name: 'Paris Saint-Germain', rank: 1, desc: 'Les Parisiens.', players: [
                    { name: 'Gianluigi Donnarumma', stats: 'GK' }, { name: 'Achraf Hakimi', stats: 'DF' }, { name: 'Marquinhos', stats: 'DF' },
                    { name: 'Nuno Mendes', stats: 'DF' }, { name: 'Warren Zaïre-Emery', stats: 'MF' }, { name: 'Vitinha', stats: 'MF' },
                    { name: 'João Neves', stats: 'MF' }, { name: 'Ousmane Dembélé', stats: 'FW' }, { name: 'Bradley Barcola', stats: 'FW' },
                    { name: 'Marco Asensio', stats: 'FW' }, { name: 'Randal Kolo Muani', stats: 'FW' }, { name: 'Lucas Beraldo', stats: 'DF' }
                ]},
                { id: 'monaco', name: 'AS Monaco', rank: 2, desc: 'Les Monégasques.', players: [
                    { name: 'Philipp Köhn', stats: 'GK' }, { name: 'Vanderson', stats: 'DF' }, { name: 'Wilfried Singo', stats: 'DF' },
                    { name: 'Mohammed Salisu', stats: 'DF' }, { name: 'Denis Zakaria', stats: 'MF' }, { name: 'Lamine Camara', stats: 'MF' },
                    { name: 'Aleksandr Golovin', stats: 'MF' }, { name: 'Takumi Minamino', stats: 'FW' }, { name: 'Maghnes Akliouche', stats: 'FW' },
                    { name: 'Breel Embolo', stats: 'FW' }, { name: 'Folarin Balogun', stats: 'FW' }, { name: 'Krépin Diatta', stats: 'MF' }
                ]},
                { id: 'marseille', name: 'Olympique de Marseille', rank: 3, desc: 'Les Phocéens.', players: [
                    { name: 'Gerónimo Rulli', stats: 'GK' }, { name: 'Leonardo Balerdi', stats: 'DF' }, { name: 'Michael Murillo', stats: 'DF' },
                    { name: 'Quentin Merlin', stats: 'DF' }, { name: 'Pierre-Emile Højbjerg', stats: 'MF' }, { name: 'Adrien Rabiot', stats: 'MF' },
                    { name: 'Geoffrey Kondogbia', stats: 'MF' }, { name: 'Amine Harit', stats: 'MF' }, { name: 'Mason Greenwood', stats: 'FW' },
                    { name: 'Elye Wahi', stats: 'FW' }, { name: 'Luis Henrique', stats: 'FW' }, { name: 'Valentin Rongier', stats: 'MF' }
                ]},
                { id: 'lille', name: 'LOSC Lille', rank: 4, desc: 'Les Dogues.', players: [
                    { name: 'Lucas Chevalier', stats: 'GK' }, { name: 'Bafodé Diakité', stats: 'DF' }, { name: 'Alexsandro', stats: 'DF' },
                    { name: 'Thomas Meunier', stats: 'DF' }, { name: 'Gabriel Gudmundsson', stats: 'DF' }, { name: 'Benjamin André', stats: 'MF' },
                    { name: 'Angel Gomes', stats: 'MF' }, { name: 'Edon Zhegrova', stats: 'FW' }, { name: 'Osame Sahraoui', stats: 'FW' },
                    { name: 'Jonathan David', stats: 'FW' }, { name: 'Rémy Cabella', stats: 'MF' }, { name: 'Mohamed Bayo', stats: 'FW' }
                ]},
                { id: 'lyon', name: 'Olympique Lyonnais', rank: 5, desc: 'Les Gones.', players: [
                    { name: 'Lucas Perri', stats: 'GK' }, { name: 'Clinton Mata', stats: 'DF' }, { name: 'Duje Ćaleta-Car', stats: 'DF' },
                    { name: 'Nicolás Tagliafico', stats: 'DF' }, { name: 'Nemanja Matić', stats: 'MF' }, { name: 'Corentin Tolisso', stats: 'MF' },
                    { name: 'Maxence Caqueret', stats: 'MF' }, { name: 'Rayan Cherki', stats: 'MF' }, { name: 'Alexandre Lacazette', stats: 'FW' },
                    { name: 'Georges Mikautadze', stats: 'FW' }, { name: 'Saïd Benrahma', stats: 'FW' }, { name: 'Ainsley Maitland-Niles', stats: 'DF' }
                ]},
                { id: 'nice', name: 'OGC Nice', rank: 6, desc: 'Les Aiglons.', players: [
                    { name: 'Marcin Bułka', stats: 'GK' }, { name: 'Antoine Mendy', stats: 'DF' }, { name: 'Moïse Bombito', stats: 'DF' },
                    { name: 'Dante', stats: 'DF' }, { name: 'Jonathan Clauss', stats: 'DF' }, { name: 'Melvin Bard', stats: 'DF' },
                    { name: 'Youssouf Ndayishimiye', stats: 'MF' }, { name: 'Pablo Rosario', stats: 'MF' }, { name: 'Hicham Boudaoui', stats: 'MF' },
                    { name: 'Mohamed-Ali Cho', stats: 'FW' }, { name: 'Evann Guessand', stats: 'FW' }, { name: 'Jérémie Boga', stats: 'FW' }
                ]},
                { id: 'lens', name: 'RC Lens', rank: 7, desc: 'Les Sang et Or.', players: [
                    { name: 'Brice Samba', stats: 'GK' }, { name: 'Jonathan Gradit', stats: 'DF' }, { name: 'Kevin Danso', stats: 'DF' },
                    { name: 'Facundo Medina', stats: 'DF' }, { name: 'Przemysław Frankowski', stats: 'MF' }, { name: 'Deiver Machado', stats: 'MF' },
                    { name: 'Andy Diouf', stats: 'MF' }, { name: 'Adrien Thomasson', stats: 'MF' }, { name: 'Florian Sotoca', stats: 'FW' },
                    { name: 'M\'Bala Nzola', stats: 'FW' }, { name: 'Wesley Saïd', stats: 'FW' }, { name: 'Hamzat Ojediran', stats: 'MF' }
                ]},
                { id: 'rennes', name: 'Stade Rennais', rank: 8, desc: 'Les Rouges et Noirs.', players: [
                    { name: 'Steve Mandanda', stats: 'GK' }, { name: 'Lorenz Assignon', stats: 'DF' }, { name: 'Leo Østigård', stats: 'DF' },
                    { name: 'Alidu Seidu', stats: 'DF' }, { name: 'Adrien Truffert', stats: 'DF' }, { name: 'Azor Matusiwa', stats: 'MF' },
                    { name: 'Glen Kamara', stats: 'MF' }, { name: 'Albert Grønbæk', stats: 'MF' }, { name: 'Ludovic Blas', stats: 'MF' },
                    { name: 'Amine Gouiri', stats: 'FW' }, { name: 'Arnaud Kalimuendo', stats: 'FW' }, { name: 'Mikayil Faye', stats: 'DF' }
                ]},
                { id: 'strasbourg', name: 'RC Strasbourg Alsace', rank: 9, desc: 'Le Racing.', players: [
                    { name: 'Đorđe Petrović', stats: 'GK' }, { name: 'Guéla Doué', stats: 'DF' }, { name: 'Saïdou Sow', stats: 'DF' },
                    { name: 'Abakar Sylla', stats: 'DF' }, { name: 'Diego Moreira', stats: 'DF' }, { name: 'Andrey Santos', stats: 'MF' },
                    { name: 'Habib Diarra', stats: 'MF' }, { name: 'Sebastian Nanasi', stats: 'MF' }, { name: 'Dilane Bakwa', stats: 'FW' },
                    { name: 'Emanuel Emegha', stats: 'FW' }, { name: 'Sékou Mara', stats: 'FW' }, { name: 'Marvin Senaya', stats: 'DF' }
                ]},
                { id: 'toulouse', name: 'Toulouse FC', rank: 10, desc: 'Le TéFéCé.', players: [
                    { name: 'Guillaume Restes', stats: 'GK' }, { name: 'Djibril Sidibé', stats: 'DF' }, { name: 'Charlie Cresswell', stats: 'DF' },
                    { name: 'Rasmus Nicolaisen', stats: 'DF' }, { name: 'Gabriel Suazo', stats: 'DF' }, { name: 'Vincent Sierro', stats: 'MF' },
                    { name: 'Cristian Cásseres Jr.', stats: 'MF' }, { name: 'Aron Dønnum', stats: 'FW' }, { name: 'Yann Gboho', stats: 'FW' },
                    { name: 'Zakaria Aboukhlal', stats: 'FW' }, { name: 'Frank Magri', stats: 'FW' }, { name: 'Shavy Babicka', stats: 'FW' }
                ]},
                { id: 'brest', name: 'Stade Brestois 29', rank: 11, desc: 'Les Pirates.', players: [
                    { name: 'Marco Bizot', stats: 'GK' }, { name: 'Kenny Lala', stats: 'DF' }, { name: 'Brendan Chardonnet', stats: 'DF' },
                    { name: 'Julien Le Cardinal', stats: 'DF' }, { name: 'Jordan Amavi', stats: 'DF' }, { name: 'Hugo Magnetti', stats: 'MF' },
                    { name: 'Pierre Lees-Melou', stats: 'MF' }, { name: 'Mahdi Camara', stats: 'MF' }, { name: 'Romain Del Castillo', stats: 'FW' },
                    { name: 'Ludovic Ajorque', stats: 'FW' }, { name: 'Abdallah Sima', stats: 'FW' }, { name: 'Jonas Martin', stats: 'MF' }
                ]},
                { id: 'nantes', name: 'FC Nantes', rank: 12, desc: 'Les Canaris.', players: [
                    { name: 'Alban Lafont', stats: 'GK' }, { name: 'Kelvin Amian', stats: 'DF' }, { name: 'Jean-Charles Castelletto', stats: 'DF' },
                    { name: 'Nathan Zeze', stats: 'DF' }, { name: 'Nicolas Cozza', stats: 'DF' }, { name: 'Pedro Chirivella', stats: 'MF' },
                    { name: 'Douglas Augusto', stats: 'MF' }, { name: 'Sorba Thomas', stats: 'MF' }, { name: 'Tino Kadewere', stats: 'FW' },
                    { name: 'Moses Simon', stats: 'FW' }, { name: 'Matthis Abline', stats: 'FW' }, { name: 'Johann Lepenant', stats: 'MF' }
                ]},
                { id: 'lehavre', name: 'Le Havre AC', rank: 13, desc: 'Le HAC.', players: [
                    { name: 'Arthur Desmas', stats: 'GK' }, { name: 'Loïc Négo', stats: 'DF' }, { name: 'Arouna Sangante', stats: 'DF' },
                    { name: 'Gautier Lloris', stats: 'DF' }, { name: 'Christopher Operi', stats: 'DF' }, { name: 'Abdoulaye Touré', stats: 'MF' },
                    { name: 'Oussama Targhalline', stats: 'MF' }, { name: 'Yassine Kechta', stats: 'MF' }, { name: 'Josué Casimir', stats: 'FW' },
                    { name: 'Issa Soumaré', stats: 'FW' }, { name: 'Antoine Joujou', stats: 'FW' }, { name: 'Daler Kuzyaev', stats: 'MF' }
                ]},
                { id: 'auxerre', name: 'AJ Auxerre', rank: 14, desc: 'AJA.', players: [
                    { name: 'Donovan Léon', stats: 'GK' }, { name: 'Paul Joly', stats: 'DF' }, { name: 'Jubal', stats: 'DF' },
                    { name: 'Gabriel Osho', stats: 'DF' }, { name: 'Clément Akpa', stats: 'DF' }, { name: 'Elisha Owusu', stats: 'MF' },
                    { name: 'Rayan Raveloson', stats: 'MF' }, { name: 'Gaëtan Perrin', stats: 'MF' }, { name: 'Hamed Traorè', stats: 'MF' },
                    { name: 'Lassine Sinayoko', stats: 'FW' }, { name: 'Theo Bair', stats: 'FW' }, { name: 'Gideon Mensah', stats: 'DF' }
                ]},
                { id: 'angers', name: 'Angers SCO', rank: 15, desc: 'Les Scoïstes.', players: [
                    { name: 'Yahia Fofana', stats: 'GK' }, { name: 'Carlens Arcus', stats: 'DF' }, { name: 'Abdoulaye Bamba', stats: 'DF' },
                    { name: 'Jordan Lefort', stats: 'DF' }, { name: 'Florent Hanin', stats: 'DF' }, { name: 'Jean-Eudes Aholou', stats: 'MF' },
                    { name: 'Haris Belkebla', stats: 'MF' }, { name: 'Jim Allevinah', stats: 'MF' }, { name: 'Himad Abdelli', stats: 'MF' },
                    { name: 'Farid El Melali', stats: 'FW' }, { name: 'Bamba Dieng', stats: 'FW' }, { name: 'Esteban Lepaul', stats: 'FW' }
                ]},
                { id: 'lorient', name: 'FC Lorient', rank: 16, desc: 'Les Merlus.', players: [
                    { name: 'Yvon Mvogo', stats: 'GK' }, { name: 'Gédéon Kalulu', stats: 'DF' }, { name: 'Montassar Talbi', stats: 'DF' },
                    { name: 'Nathaniel Adjei', stats: 'DF' }, { name: 'Darlin Yongwa', stats: 'DF' }, { name: 'Laurent Abergel', stats: 'MF' },
                    { name: 'Julien Ponceau', stats: 'MF' }, { name: 'Pablo Pagis', stats: 'MF' }, { name: 'Eli Junior Kroupi', stats: 'FW' },
                    { name: 'Mohamed Bamba', stats: 'FW' }, { name: 'Aiyegun Tosin', stats: 'FW' }, { name: 'Igor Silva', stats: 'DF' }
                ]},
                { id: 'metz', name: 'FC Metz', rank: 17, desc: 'Les Grenats.', players: [
                    { name: 'Alexandre Oukidja', stats: 'GK' }, { name: 'Maxime Colin', stats: 'DF' }, { name: 'Ismaël Traoré', stats: 'DF' },
                    { name: 'Sadibou Sané', stats: 'DF' }, { name: 'Matthieu Udol', stats: 'DF' }, { name: 'Danley Jean Jacques', stats: 'MF' },
                    { name: 'Joseph Nduquidi', stats: 'MF' }, { name: 'Ablie Jallow', stats: 'MF' }, { name: 'Cheikh Sabaly', stats: 'FW' },
                    { name: 'Pape Amadou Diallo', stats: 'FW' }, { name: 'Joel Asoro', stats: 'FW' }, { name: 'Koffi Kouao', stats: 'DF' }
                ]},
                { id: 'parisfc', name: 'Paris FC', rank: 18, desc: 'Les Parisiens.', players: [
                    { name: 'Obed Nkambadio', stats: 'GK' }, { name: 'Almamy Touré', stats: 'DF' }, { name: 'Moustapha Mbow', stats: 'DF' },
                    { name: 'Timothée Kolodziejczak', stats: 'DF' }, { name: 'Jules Gaudin', stats: 'DF' }, { name: 'Cyril Mandouki', stats: 'MF' },
                    { name: 'Lohann Doucet', stats: 'MF' }, { name: 'Ilan Kebbal', stats: 'MF' }, { name: 'Alimami Gory', stats: 'FW' },
                    { name: 'Nouha Dicko', stats: 'FW' }, { name: 'Jean-Philippe Krasso', stats: 'FW' }, { name: 'Maxime Lopez', stats: 'MF' }
                ]}
            ]
        }
    ],
    cricket: [
        {
            id: 'ipl', name: 'Indian Premier League (IPL)', desc: 'The premier T20 franchise league (10 Teams).',
            teams: [
                { id: 'csk', name: 'Chennai Super Kings', rank: 1, desc: 'Whistle Podu.', players: [
                    { name: 'Ruturaj Gaikwad', stats: 'BAT' }, { name: 'MS Dhoni', stats: 'WK' }, { name: 'Ravindra Jadeja', stats: 'AR' },
                    { name: 'Matheesha Pathirana', stats: 'BOWL' }, { name: 'Shivam Dube', stats: 'AR' }, { name: 'Sanju Samson', stats: 'WK' },
                    { name: 'Noor Ahmad', stats: 'BOWL' }, { name: 'Khaleel Ahmed', stats: 'BOWL' }, { name: 'Rahul Tripathi', stats: 'BAT' }
                ]},
                { id: 'mi', name: 'Mumbai Indians', rank: 2, desc: 'One Family.', players: [
                    { name: 'Hardik Pandya', stats: 'AR' }, { name: 'Rohit Sharma', stats: 'BAT' }, { name: 'Jasprit Bumrah', stats: 'BOWL' },
                    { name: 'Suryakumar Yadav', stats: 'BAT' }, { name: 'Tilak Varma', stats: 'BAT' }, { name: 'Trent Boult', stats: 'BOWL' },
                    { name: 'Deepak Chahar', stats: 'BOWL' }, { name: 'Will Jacks', stats: 'AR' }, { name: 'Mitchell Santner', stats: 'AR' }
                ]},
                { id: 'kkr', name: 'Kolkata Knight Riders', rank: 3, desc: 'Korbo Lorbo Jeetbo.', players: [
                    { name: 'Ajinkya Rahane', stats: 'BAT' }, { name: 'Sunil Narine', stats: 'AR' }, { name: 'Andre Russell', stats: 'AR' },
                    { name: 'Varun Chakaravarthy', stats: 'BOWL' }, { name: 'Rinku Singh', stats: 'BAT' }, { name: 'Quinton de Kock', stats: 'WK' },
                    { name: 'Venkatesh Iyer', stats: 'AR' }, { name: 'Harshit Rana', stats: 'BOWL' }, { name: 'Anrich Nortje', stats: 'BOWL' }
                ]},
                { id: 'rr', name: 'Rajasthan Royals', rank: 4, desc: 'Halla Bol.', players: [
                    { name: 'Yashasvi Jaiswal', stats: 'BAT' }, { name: 'Riyan Parag', stats: 'AR' }, { name: 'Dhruv Jurel', stats: 'WK' },
                    { name: 'Sandeep Sharma', stats: 'BOWL' }, { name: 'Shimron Hetmyer', stats: 'BAT' }, { name: 'Rovman Powell', stats: 'BAT' },
                    { name: 'Avesh Khan', stats: 'BOWL' }, { name: 'Donovan Ferreira', stats: 'WK' }, { name: 'Kuldeep Sen', stats: 'BOWL' }
                ]},
                { id: 'srh', name: 'Sunrisers Hyderabad', rank: 5, desc: 'Orange Army.', players: [
                    { name: 'Pat Cummins', stats: 'BOWL' }, { name: 'Heinrich Klaasen', stats: 'WK' }, { name: 'Travis Head', stats: 'BAT' },
                    { name: 'Abhishek Sharma', stats: 'AR' }, { name: 'Nitish Kumar Reddy', stats: 'AR' }, { name: 'Mayank Markande', stats: 'BOWL' },
                    { name: 'T Natarajan', stats: 'BOWL' }, { name: 'Washington Sundar', stats: 'AR' }, { name: 'Abdul Samad', stats: 'BAT' }
                ]},
                { id: 'rcb', name: 'Royal Challengers Bengaluru', rank: 6, desc: 'Play Bold.', players: [
                    { name: 'Virat Kohli', stats: 'BAT' }, { name: 'Rajat Patidar', stats: 'BAT' }, { name: 'Liam Livingstone', stats: 'AR' },
                    { name: 'Phil Salt', stats: 'WK' }, { name: 'Josh Hazlewood', stats: 'BOWL' }, { name: 'Bhuvneshwar Kumar', stats: 'BOWL' },
                    { name: 'Jitesh Sharma', stats: 'WK' }, { name: 'Yash Dayal', stats: 'BOWL' }, { name: 'Krunal Pandya', stats: 'AR' }
                ]},
                { id: 'dc', name: 'Delhi Capitals', rank: 7, desc: 'Roar Macha.', players: [
                    { name: 'Axar Patel', stats: 'AR' }, { name: 'Kuldeep Yadav', stats: 'BOWL' }, { name: 'Tristan Stubbs', stats: 'WK' },
                    { name: 'Abishek Porel', stats: 'WK' }, { name: 'Jake Fraser-McGurk', stats: 'BAT' }, { name: 'Mukesh Kumar', stats: 'BOWL' },
                    { name: 'Ishant Sharma', stats: 'BOWL' }, { name: 'Pravin Dubey', stats: 'BOWL' }, { name: 'Harry Brook', stats: 'BAT' }
                ]},
                { id: 'lsg', name: 'Lucknow Super Giants', rank: 8, desc: 'Adab Se Harayenge.', players: [
                    { name: 'Nicholas Pooran', stats: 'WK' }, { name: 'Mayank Yadav', stats: 'BOWL' }, { name: 'Ravi Bishnoi', stats: 'BOWL' },
                    { name: 'Ayush Badoni', stats: 'BAT' }, { name: 'Mohsin Khan', stats: 'BOWL' }, { name: 'Marcus Stoinis', stats: 'AR' },
                    { name: 'Deepak Hooda', stats: 'AR' }, { name: 'Devdutt Padikkal', stats: 'BAT' }, { name: 'Naveen-ul-Haq', stats: 'BOWL' }
                ]},
                { id: 'gt', name: 'Gujarat Titans', rank: 9, desc: 'Aava De.', players: [
                    { name: 'Shubman Gill', stats: 'BAT' }, { name: 'Rashid Khan', stats: 'BOWL' }, { name: 'Sai Sudharsan', stats: 'BAT' },
                    { name: 'Rahul Tewatia', stats: 'AR' }, { name: 'Shahrukh Khan', stats: 'BAT' }, { name: 'David Miller', stats: 'BAT' },
                    { name: 'Mohit Sharma', stats: 'BOWL' }, { name: 'Vijay Shankar', stats: 'AR' }, { name: 'Spencer Johnson', stats: 'BOWL' }
                ]},
                { id: 'pbks', name: 'Punjab Kings', rank: 10, desc: 'Sadda Punjab.', players: [
                    { name: 'Shashank Singh', stats: 'BAT' }, { name: 'Prabhsimran Singh', stats: 'WK' }, { name: 'Sam Curran', stats: 'AR' },
                    { name: 'Arshdeep Singh', stats: 'BOWL' }, { name: 'Kagiso Rabada', stats: 'BOWL' }, { name: 'Harshal Patel', stats: 'BOWL' },
                    { name: 'Jonny Bairstow', stats: 'WK' }, { name: 'Rahul Chahar', stats: 'BOWL' }, { name: 'Sikandar Raza', stats: 'AR' }
                ]}
            ]
        },
        {
            id: 'bbl', name: 'Big Bash League (BBL)', desc: 'Australia\'s premier T20 competition (8 Teams).',
            teams: [
                { id: 'perth', name: 'Perth Scorchers', rank: 1, desc: 'The Furnace.', players: [
                    { name: 'Ashton Turner', stats: 'BAT' }, { name: 'Ashton Agar', stats: 'AR' }, { name: 'Jason Behrendorff', stats: 'BOWL' },
                    { name: 'Aaron Hardie', stats: 'AR' }, { name: 'Josh Inglis', stats: 'WK' }, { name: 'Mitchell Marsh', stats: 'AR' },
                    { name: 'Jhye Richardson', stats: 'BOWL' }, { name: 'Andrew Tye', stats: 'BOWL' }, { name: 'Finn Allen', stats: 'BAT' }
                ]},
                { id: 'sixers', name: 'Sydney Sixers', rank: 2, desc: 'Magenta.', players: [
                    { name: 'Moises Henriques', stats: 'AR' }, { name: 'Sean Abbott', stats: 'BOWL' }, { name: 'Josh Philippe', stats: 'WK' },
                    { name: 'Steve Smith', stats: 'BAT' }, { name: 'Daniel Hughes', stats: 'BAT' }, { name: 'Jordan Silk', stats: 'BAT' },
                    { name: 'Babar Azam', stats: 'BAT' }, { name: 'Sam Curran', stats: 'AR' }, { name: 'Ben Dwarshuis', stats: 'BOWL' }
                ]},
                { id: 'heat', name: 'Brisbane Heat', rank: 3, desc: 'Teal.', players: [
                    { name: 'Usman Khawaja', stats: 'BAT' }, { name: 'Marnus Labuschagne', stats: 'BAT' }, { name: 'Michael Neser', stats: 'AR' },
                    { name: 'Spencer Johnson', stats: 'BOWL' }, { name: 'Matt Renshaw', stats: 'BAT' }, { name: 'Jimmy Peirson', stats: 'WK' },
                    { name: 'Xavier Bartlett', stats: 'BOWL' }, { name: 'Shaheen Afridi', stats: 'BOWL' }, { name: 'Colin Munro', stats: 'BAT' }
                ]},
                { id: 'strikers', name: 'Adelaide Strikers', rank: 4, desc: 'Cornflower Blue.', players: [
                    { name: 'Matt Short', stats: 'AR' }, { name: 'Alex Carey', stats: 'WK' }, { name: 'Chris Lynn', stats: 'BAT' },
                    { name: 'Jamie Overton', stats: 'AR' }, { name: 'Hassan Ali', stats: 'BOWL' }, { name: 'Henry Thornton', stats: 'BOWL' },
                    { name: 'Lloyd Pope', stats: 'BOWL' }, { name: 'Jason Sangha', stats: 'BAT' }, { name: 'Mackenzie Harvey', stats: 'BAT' }
                ]},
                { id: 'hurricanes', name: 'Hobart Hurricanes', rank: 5, desc: 'Purple.', players: [
                    { name: 'Nathan Ellis', stats: 'BOWL' }, { name: 'Matthew Wade', stats: 'WK' }, { name: 'Ben McDermott', stats: 'BAT' },
                    { name: 'Tim David', stats: 'BAT' }, { name: 'Riley Meredith', stats: 'BOWL' }, { name: 'Chris Jordan', stats: 'BOWL' },
                    { name: 'Mac Wright', stats: 'BAT' }, { name: 'Rehan Ahmed', stats: 'BOWL' }, { name: 'Beau Webster', stats: 'AR' }
                ]},
                { id: 'renegades', name: 'Melbourne Renegades', rank: 6, desc: 'Red.', players: [
                    { name: 'Will Sutherland', stats: 'AR' }, { name: 'Adam Zampa', stats: 'BOWL' }, { name: 'Nathan Lyon', stats: 'BOWL' },
                    { name: 'Josh Brown', stats: 'BAT' }, { name: 'Jake Fraser-McGurk', stats: 'BAT' }, { name: 'Kane Richardson', stats: 'BOWL' },
                    { name: 'Tim Seifert', stats: 'WK' }, { name: 'Laurie Evans', stats: 'BAT' }, { name: 'Marcus Harris', stats: 'BAT' }
                ]},
                { id: 'stars', name: 'Melbourne Stars', rank: 7, desc: 'Green.', players: [
                    { name: 'Glenn Maxwell', stats: 'AR' }, { name: 'Marcus Stoinis', stats: 'AR' }, { name: 'Scott Boland', stats: 'BOWL' },
                    { name: 'Haris Rauf', stats: 'BOWL' }, { name: 'Tom Curran', stats: 'AR' }, { name: 'Sam Harper', stats: 'WK' },
                    { name: 'Hilton Cartwright', stats: 'BAT' }, { name: 'Campbell Kellaway', stats: 'BAT' }, { name: 'Peter Siddle', stats: 'BOWL' }
                ]},
                { id: 'thunder', name: 'Sydney Thunder', rank: 8, desc: 'Electric Green.', players: [
                    { name: 'David Warner', stats: 'BAT' }, { name: 'Daniel Sams', stats: 'AR' }, { name: 'Tanveer Sangha', stats: 'BOWL' },
                    { name: 'Lockie Ferguson', stats: 'BOWL' }, { name: 'Shadab Khan', stats: 'AR' }, { name: 'Sam Billings', stats: 'WK' },
                    { name: 'Chris Green', stats: 'BOWL' }, { name: 'Oliver Davies', stats: 'BAT' }, { name: 'Cameron Bancroft', stats: 'BAT' }
                ]}
            ]
        }
    ]
};

// Data Rendering Logic
function renderLeagues(sportCategory, containerId) {
    const container = document.getElementById(containerId);
    let html = '';

    sportsData[sportCategory].forEach((league) => {
        html += `
        <div class="accordion-item shadow-sm mb-3">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#league-${league.id}">
                    ${league.name}
                </button>
            </h2>
            <div id="league-${league.id}" class="accordion-collapse collapse" data-bs-parent="#${containerId}">
                <div class="accordion-body">
                    <div class="alert alert-success py-2" style="font-size: 0.9rem;">${league.desc}</div>
                    <div class="accordion" id="teams-${league.id}">`;

        league.teams.forEach((team) => {
            html += `
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#team-${team.id}">
                                    <span class="badge bg-dark me-2">RANK ${team.rank}</span> ${team.name}
                                </button>
                            </h2>
                            <div id="team-${team.id}" class="accordion-collapse collapse" data-bs-parent="#teams-${league.id}">
                                <div class="accordion-body bg-light">
                                    <p class="small text-muted">${team.desc}</p>
                                    <div class="row g-2">`;
            
            if (team.players && team.players.length > 0) {
                team.players.forEach(player => {
                    html += `
                                        <div class="col-md-6">
                                            <div class="p-2 border rounded bg-white d-flex justify-content-between">
                                                <span class="fw-semibold">${player.name}</span>
                                                <span class="badge bg-outline-success text-dark border border-success">${player.stats}</span>
                                            </div>
                                        </div>`;
                });
            } else {
                html += `<div class="col-12 text-center text-muted py-2">Full squad updating shortly...</div>`;
            }

            html += `               </div>
                                </div>
                            </div>
                        </div>`;
        });

        html += `   </div>
                </div>
            </div>
        </div>`;
    });

    container.innerHTML = html;
}

// Simulated Real-Time Refresh
function refreshData() {
    renderLeagues('football', 'football-container');
    renderLeagues('cricket', 'cricket-container');
    document.getElementById('lastUpdated').innerText = `Sync: ${new Date().toLocaleTimeString()}`;
}

refreshData();
setInterval(refreshData, 30000); // Updates every 30 seconds
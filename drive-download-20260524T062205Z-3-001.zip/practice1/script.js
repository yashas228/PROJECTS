const data = {
  sports: [
    {
      name: 'Football',
      leagues: [
        {
          name: 'Premier League',
          description: 'English top-tier league with global fanbase.',
          teams: [
            {
              name: 'Manchester City',
              description: 'Current powerhouse with multiple recent titles.',
              image: 'https://upload.wikimedia.org/wikipedia/en/e/ee/Manchester_City_FC_badge.svg',
              website: 'https://www.mancity.com/',
              players: [
                { name: 'Erling Haaland', description: 'Prolific goal-scorer from Norway.' },
                { name: 'Kevin De Bruyne', description: 'Creative midfield engine.' }
              ],
              stats: { rank: 1, played: 38, won: 29, drawn: 6, lost: 3 }
            },
            {
              name: 'Liverpool',
              description: 'Historic Reds with thrilling attacking football.',
              image: 'https://upload.wikimedia.org/wikipedia/en/0/0c/Liverpool_FC.svg',
              website: 'https://www.liverpoolfc.com/',
              players: [
                { name: 'Mohamed Salah', description: 'Elite winger and regular scorer.' },
                { name: 'Virgil van Dijk', description: 'World-class centre-back.' }
              ],
              stats: { rank: 2, played: 38, won: 28, drawn: 7, lost: 3 }
            }
          ]
        },
        {
          name: 'La Liga',
          description: 'Spanish league home to Barcelona and Real Madrid.',
          teams: [
            {
              name: 'Real Madrid',
              description: 'Record European champions with elite form.',
              image: 'https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg',
              website: 'https://www.realmadrid.com/',
              players: [
                { name: 'Karim Benzema', description: 'Clinical striker and leader.' },
                { name: 'Luka Modric', description: 'Legendary midfield veteran.' }
              ],
              stats: { rank: 1, played: 38, won: 26, drawn: 8, lost: 4 }
            },
            {
              name: 'FC Barcelona',
              description: 'Youthful and stylish Catalan giants.',
              image: 'https://upload.wikimedia.org/wikipedia/en/4/47/FC_Barcelona_%28crest%29.svg',
              website: 'https://www.fcbarcelona.com/',
              players: [
                { name: 'Robert Lewandowski', description: 'Seasoned goal machine.' },
                { name: 'Pedri', description: 'Creative young midfielder.' }
              ],
              stats: { rank: 3, played: 38, won: 25, drawn: 9, lost: 4 }
            }
          ]
        }
      ]
    },
    {
      name: 'Basketball',
      leagues: [
        {
          name: 'NBA',
          description: 'American professional basketball league featuring top global talent.',
          teams: [
            {
              name: 'Golden State Warriors',
              description: 'Dynamically paced play with sharpshooting stars.',
              image: 'https://upload.wikimedia.org/wikipedia/en/0/01/Golden_State_Warriors_logo.svg',
              website: 'https://www.nba.com/warriors/',
              players: [
                { name: 'Stephen Curry', description: 'Greatest shooter ever.' },
                { name: 'Klay Thompson', description: 'Elite perimeter scorer.' }
              ],
              stats: { rank: 1, played: 82, won: 58, lost: 24 }
            },
            {
              name: 'Los Angeles Lakers',
              description: 'Legacy franchise with championship aspirations.',
              image: 'https://upload.wikimedia.org/wikipedia/commons/3/3c/Los_Angeles_Lakers_logo.svg',
              website: 'https://www.nba.com/lakers/',
              players: [
                { name: 'LeBron James', description: 'All-time great and leader.' },
                { name: 'Anthony Davis', description: 'Dominant two-way big man.' }
              ],
              stats: { rank: 4, played: 82, won: 48, lost: 34 }
            }
          ]
        }
      ]
    },
    {
      name: 'Cricket',
      leagues: [
        {
          name: 'Indian Premier League (IPL)',
          description: 'Top T20 league with world stars and huge fan engagement.',
          teams: [
            {
              name: 'Mumbai Indians',
              description: 'Most successful IPL franchise with many trophies.',
              image: 'https://upload.wikimedia.org/wikipedia/en/2/2e/Mumbai_Indians_Logo.svg',
              website: 'https://www.mumbaiindians.com/',
              players: [
                { name: 'Rohit Sharma', description: 'Captain and opener with big-match temperament.' },
                { name: 'Jasprit Bumrah', description: 'Watchful fast bowler with yorker mastery.' }
              ],
              stats: { rank: 1, played: 14, won: 10, lost: 4 }
            },
            {
              name: 'Chennai Super Kings',
              description: 'Consistent playoffs team led by MS Dhoni.',
              image: 'https://upload.wikimedia.org/wikipedia/en/6/6f/Chennai_Super_Kings_Logo.svg',
              website: 'https://www.chennaisuperkings.com/',
              players: [
                { name: 'MS Dhoni', description: 'Calm finisher and super captain.' },
                { name: 'Ravindra Jadeja', description: 'All-rounder with key contributions.' }
              ],
              stats: { rank: 2, played: 14, won: 9, lost: 5 }
            }
          ]
        }
      ]
    }
  ]
};

const dailyMatches = [
  { text: 'Manchester City 3-1 Liverpool | Haaland hat-trick headline', club: 'Manchester City' },
  { text: 'Real Madrid 2-2 Barcelona | El Clasico weekend thriller', club: 'Real Madrid' },
  { text: 'Warriors 125-115 Lakers | Curry dazzles', club: 'Golden State Warriors' },
  { text: 'Mumbai Indians 180/5 chase CSK 175/8 | Rohit top-scored 88*', club: 'Mumbai Indians' }
];

const state = {
  selectedSport: 'All',
  selectedLeague: 'All',
  searchTerm: ''
};

const lastUpdatedEl = document.getElementById('lastUpdated');
const sportFilter = document.getElementById('sportFilter');
const leagueFilter = document.getElementById('leagueFilter');
const searchInput = document.getElementById('searchInput');
const clubList = document.getElementById('clubList');
const dailySummary = document.getElementById('dailySummary');
const sportChartCtx = document.getElementById('sportChart');
let sportChart = null;

function getSportCounts() {
  const counts = {};
  data.sports.forEach(s => {
    counts[s.name] = s.leagues.reduce((acc, l) => acc + l.teams.length, 0);
  });
  return counts;
}

function renderSportChart() {
  const sportLabels = Object.keys(getSportCounts());
  const sportData = Object.values(getSportCounts());

  if (sportChart) sportChart.destroy();

  sportChart = new Chart(sportChartCtx, {
    type: 'doughnut',
    data: {
      labels: sportLabels,
      datasets: [{
        label: 'Teams per Sport',
        data: sportData,
        backgroundColor: ['#0d6efd', '#5bc0eb', '#f25f5c', '#ffb703', '#3f37c9'],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom' }
      }
    }
  });
}

function formatDate(d) {
  return d.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' });
}

function renderFilters() {
  const sports = ['All', ...data.sports.map(s => s.name)];
  sportFilter.innerHTML = sports.map(name => `<option>${name}</option>`).join('');

  const leagues = new Set();
  data.sports.forEach(s => s.leagues.forEach(l => leagues.add(l.name)));
  const leagueOptions = ['All', ...leagues];
  leagueFilter.innerHTML = leagueOptions.map(name => `<option>${name}</option>`).join('');
}

function getFilteredClubs() {
  const term = state.searchTerm.trim().toLowerCase();
  let results = [];

  data.sports.forEach(sport => {
    if (state.selectedSport !== 'All' && sport.name !== state.selectedSport) return;

    sport.leagues.forEach(league => {
      if (state.selectedLeague !== 'All' && league.name !== state.selectedLeague) return;

      league.teams.forEach(team => {
        const teamMatch = team.name.toLowerCase().includes(term) || team.description.toLowerCase().includes(term);
        const playerMatch = team.players.some(player => player.name.toLowerCase().includes(term) || player.description.toLowerCase().includes(term));

        if (!term || teamMatch || playerMatch) {
          results.push({ sport: sport.name, league: league.name, leagueDescription: league.description, team });
        }
      });
    });
  });

  return results.slice(0, 20);
}

function renderClubs() {
  const clubs = getFilteredClubs();

  clubList.innerHTML = clubs.length ? clubs.map(item => {
    const players = item.team.players.map(p => `<li class="small">${p.name}: ${p.description}</li>`).join('');
    const stats = item.team.stats ? `<p class="mb-1 small"><strong>Stats:</strong> ${Object.entries(item.team.stats).map(([k, v]) => `${k}= ${v}`).join(' • ')}</p>` : '';

    const imageBlock = item.team.image ? `<img src="${item.team.image}" alt="${item.team.name}" class="team-img mb-2 rounded mx-auto d-block" loading="lazy" />` : '';
    const websiteBlock = item.team.website ? `<p class="mb-2"><a href="${item.team.website}" target="_blank" rel="noopener noreferrer" class="text-decoration-none">Official website</a></p>` : '';

    return `
      <article class="col">
        <div class="card card-club h-100">
          <div class="card-body">
            ${imageBlock}
            <h3 class="h5 card-title">${item.team.name}</h3>
            <p class="card-text">${item.team.description}</p>
            ${websiteBlock}
            <p class="mb-2 club-badge badge bg-primary">Sport: ${item.sport}</p>
            <p class="mb-2 club-badge badge bg-success">League: ${item.league}</p>
            <p class="mb-2 club-badge text-muted small">League info: ${item.leagueDescription}</p>
            ${stats}
            <h4 class="h6 mt-2">Key Players</h4>
            <ul class="ps-3 small">${players}</ul>
          </div>
        </div>
      </article>
    `;
  }).join('') : '<div class="col"><div class="alert alert-warning">No clubs match the current filters/search.</div></div>';
}

function renderDailySummary() {
  dailySummary.innerHTML = dailyMatches.map(item => `<div class="list-group-item">${item.text}</div>`).join('');
}

function refreshData() {
  // Simulate daily update by toggling a stat sample and timestamp
  data.sports.forEach(sport => {
    sport.leagues.forEach(league => {
      league.teams.forEach(team => {
        if (team.stats && team.stats.played !== undefined) {
          team.stats.played += 1;
          team.stats.won += Math.round(Math.random() * 1);
          team.stats.lost += Math.round(Math.random() * 1);
        }
      });
    });
  });

  const time = new Date();
  lastUpdatedEl.textContent = `Last update: ${formatDate(time)}`;
  renderClubs();
  renderDailySummary();
  renderSportChart();
}

sportFilter.addEventListener('input', (e) => {
  state.selectedSport = e.target.value;
  renderClubs();
});

leagueFilter.addEventListener('input', (e) => {
  state.selectedLeague = e.target.value;
  renderClubs();
});

searchInput.addEventListener('input', (e) => {
  state.searchTerm = e.target.value;
  renderClubs();
});

document.getElementById('refreshData').addEventListener('click', () => {
  refreshData();
});

window.addEventListener('DOMContentLoaded', () => {
  renderFilters();
  refreshData();
});

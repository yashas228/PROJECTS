// Image Generator Helper (Creates instant profile pictures based on names)
const getPlayerImg = (name) => `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&color=fff&size=128`;
const getTeamLogo = (name) => `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=0f172a&color=10b981&size=128`;

const sportsData = {
    football: [
        {
            id: 'epl', name: 'English Premier League (EPL)', desc: 'The top tier of English football.',
            teams: [
                { id: 'arsenal', name: 'Arsenal', rank: 1, logo: getTeamLogo('Arsenal'), desc: 'North London Giants.', players: [
                    { name: 'Bukayo Saka', stats: 'Goals: 14 | Ast: 8', img: getPlayerImg('Bukayo Saka') },
                    { name: 'Martin Ødegaard', stats: 'Goals: 8 | Ast: 10', img: getPlayerImg('Martin Odegaard') },
                    { name: 'Declan Rice', stats: 'Tackles: 65', img: getPlayerImg('Declan Rice') }
                ]},
                { id: 'mancity', name: 'Manchester City', rank: 2, logo: getTeamLogo('Man City'), desc: 'The Citizens.', players: [
                    { name: 'Erling Haaland', stats: 'Goals: 25 | Ast: 4', img: getPlayerImg('Erling Haaland') },
                    { name: 'Kevin De Bruyne', stats: 'Goals: 4 | Ast: 15', img: getPlayerImg('Kevin De Bruyne') },
                    { name: 'Phil Foden', stats: 'Goals: 12 | Ast: 7', img: getPlayerImg('Phil Foden') }
                ]},
                { id: 'manutd', name: 'Manchester United', rank: 6, logo: getTeamLogo('Man Utd'), desc: 'Red Devils.', players: [
                    { name: 'Bruno Fernandes', stats: 'Goals: 9 | Ast: 8', img: getPlayerImg('Bruno Fernandes') },
                    { name: 'Marcus Rashford', stats: 'Goals: 7 | Ast: 4', img: getPlayerImg('Marcus Rashford') },
                    { name: 'Kobbie Mainoo', stats: 'Pass Acc: 89%', img: getPlayerImg('Kobbie Mainoo') }
                ]},
                { id: 'liverpool', name: 'Liverpool', rank: 3, logo: getTeamLogo('Liverpool'), desc: 'The Reds.', players: [
                    { name: 'Mohamed Salah', stats: 'Goals: 18 | Ast: 9', img: getPlayerImg('Mohamed Salah') },
                    { name: 'Virgil van Dijk', stats: 'Clean Sheets: 10', img: getPlayerImg('Virgil van Dijk') }
                ]},
                { id: 'chelsea', name: 'Chelsea', rank: 5, logo: getTeamLogo('Chelsea'), desc: 'The Blues.', players: [
                    { name: 'Cole Palmer', stats: 'Goals: 20 | Ast: 9', img: getPlayerImg('Cole Palmer') },
                    { name: 'Enzo Fernández', stats: 'Pass Acc: 90%', img: getPlayerImg('Enzo Fernandez') }
                ]},
                // Additional requested EPL teams...
                { id: 'astonvilla', name: 'Aston Villa', rank: 4, logo: getTeamLogo('Aston Villa'), desc: 'The Villans.', players: [{ name: 'Ollie Watkins', stats: 'Goals: 16', img: getPlayerImg('Ollie Watkins') }] },
                { id: 'newcastle', name: 'Newcastle United', rank: 7, logo: getTeamLogo('Newcastle'), desc: 'The Magpies.', players: [{ name: 'Alexander Isak', stats: 'Goals: 15', img: getPlayerImg('Alexander Isak') }] },
                { id: 'westham', name: 'West Ham United', rank: 8, logo: getTeamLogo('West Ham'), desc: 'The Hammers.', players: [{ name: 'Jarrod Bowen', stats: 'Goals: 14', img: getPlayerImg('Jarrod Bowen') }] },
                { id: 'tottenham', name: 'Tottenham Hotspur', rank: 9, logo: getTeamLogo('Spurs'), desc: 'Lilywhites.', players: [{ name: 'Son Heung-min', stats: 'Goals: 15', img: getPlayerImg('Son Heung-min') }] },
                { id: 'brighton', name: 'Brighton', rank: 10, logo: getTeamLogo('Brighton'), desc: 'The Seagulls.', players: [{ name: 'Kaoru Mitoma', stats: 'Goals: 5', img: getPlayerImg('Kaoru Mitoma') }] }
            ]
        },
        {
            id: 'seriea', name: 'Serie A (Italy)', desc: 'The pinnacle of Italian football.',
            teams: [
                { id: 'inter', name: 'Inter Milan', rank: 1, logo: getTeamLogo('Inter'), desc: 'I Nerazzurri.', players: [
                    { name: 'Lautaro Martínez', stats: 'Goals: 22 | Ast: 5', img: getPlayerImg('Lautaro Martinez') },
                    { name: 'Nicolò Barella', stats: 'Goals: 3 | Ast: 7', img: getPlayerImg('Nicolo Barella') }
                ]},
                { id: 'acmilan', name: 'AC Milan', rank: 2, logo: getTeamLogo('AC Milan'), desc: 'I Rossoneri.', players: [
                    { name: 'Rafael Leão', stats: 'Goals: 10 | Ast: 8', img: getPlayerImg('Rafael Leao') },
                    { name: 'Christian Pulisic', stats: 'Goals: 11 | Ast: 6', img: getPlayerImg('Christian Pulisic') }
                ]},
                { id: 'juventus', name: 'Juventus', rank: 3, logo: getTeamLogo('Juventus'), desc: 'I Bianconeri.', players: [
                    { name: 'Dušan Vlahović', stats: 'Goals: 16', img: getPlayerImg('Dusan Vlahovic') }
                ]},
                { id: 'napoli', name: 'Napoli', rank: 4, logo: getTeamLogo('Napoli'), desc: 'Gli Azzurri.', players: [
                    { name: 'Khvicha Kvaratskhelia', stats: 'Goals: 10', img: getPlayerImg('Khvicha Kvaratskhelia') }
                ]},
                { id: 'roma', name: 'AS Roma', rank: 5, logo: getTeamLogo('Roma'), desc: 'I Giallorossi.', players: [
                    { name: 'Paulo Dybala', stats: 'Goals: 12', img: getPlayerImg('Paulo Dybala') }
                ]}
            ]
        },
        {
            id: 'ligue1', name: 'Ligue 1 (France)', desc: 'The French first division.',
            teams: [
                { id: 'psg', name: 'Paris Saint-Germain', rank: 1, logo: getTeamLogo('PSG'), desc: 'Les Parisiens.', players: [
                    { name: 'Ousmane Dembélé', stats: 'Goals: 8 | Ast: 12', img: getPlayerImg('Ousmane Dembele') },
                    { name: 'Warren Zaïre-Emery', stats: 'Pass Acc: 92%', img: getPlayerImg('Warren Zaire-Emery') }
                ]},
                { id: 'monaco', name: 'AS Monaco', rank: 2, logo: getTeamLogo('Monaco'), desc: 'Les Monégasques.', players: [
                    { name: 'Folarin Balogun', stats: 'Goals: 10', img: getPlayerImg('Folarin Balogun') }
                ]},
                { id: 'marseille', name: 'Olympique de Marseille', rank: 3, logo: getTeamLogo('Marseille'), desc: 'Les Phocéens.', players: [
                    { name: 'Pierre-Emerick Aubameyang', stats: 'Goals: 14', img: getPlayerImg('Pierre Aubameyang') }
                ]}
            ]
        }
    ],
    cricket: [
        {
            id: 'ipl', name: 'Indian Premier League (IPL)', desc: 'The biggest T20 league in the world.',
            teams: [
                { id: 'mi', name: 'Mumbai Indians', rank: 1, logo: getTeamLogo('Mumbai'), desc: 'One Family.', players: [
                    { name: 'Hardik Pandya', stats: 'Runs: 350 | Wickets: 12', img: getPlayerImg('Hardik Pandya') },
                    { name: 'Rohit Sharma', stats: 'Runs: 450 | SR: 145', img: getPlayerImg('Rohit Sharma') },
                    { name: 'Jasprit Bumrah', stats: 'Wickets: 22 | Econ: 6.5', img: getPlayerImg('Jasprit Bumrah') }
                ]},
                { id: 'csk', name: 'Chennai Super Kings', rank: 2, logo: getTeamLogo('CSK'), desc: 'Whistle Podu.', players: [
                    { name: 'MS Dhoni', stats: 'Runs: 200 | SR: 180', img: getPlayerImg('MS Dhoni') },
                    { name: 'Ruturaj Gaikwad', stats: 'Runs: 550 | 50s: 5', img: getPlayerImg('Ruturaj Gaikwad') }
                ]},
                { id: 'rcb', name: 'Royal Challengers Bengaluru', rank: 3, logo: getTeamLogo('RCB'), desc: 'Play Bold.', players: [
                    { name: 'Virat Kohli', stats: 'Runs: 700 | 100s: 2', img: getPlayerImg('Virat Kohli') },
                    { name: 'Mohammed Siraj', stats: 'Wickets: 18', img: getPlayerImg('Mohammed Siraj') }
                ]},
                { id: 'kkr', name: 'Kolkata Knight Riders', rank: 4, logo: getTeamLogo('KKR'), desc: 'Korbo Lorbo Jeetbo.', players: [
                    { name: 'Shreyas Iyer', stats: 'Runs: 400', img: getPlayerImg('Shreyas Iyer') },
                    { name: 'Sunil Narine', stats: 'Wickets: 16 | Econ: 6.8', img: getPlayerImg('Sunil Narine') }
                ]}
            ]
        },
        {
            id: 'bbl', name: 'Big Bash League (BBL)', desc: 'Australia’s premier T20 competition.',
            teams: [
                { id: 'scorchers', name: 'Perth Scorchers', rank: 1, logo: getTeamLogo('Perth'), desc: 'The Furnace.', players: [
                    { name: 'Ashton Turner', stats: 'Runs: 320', img: getPlayerImg('Ashton Turner') },
                    { name: 'Jhye Richardson', stats: 'Wickets: 19', img: getPlayerImg('Jhye Richardson') }
                ]},
                { id: 'sixers', name: 'Sydney Sixers', rank: 2, logo: getTeamLogo('Sydney'), desc: 'Magenta.', players: [
                    { name: 'Moises Henriques', stats: 'Runs: 290', img: getPlayerImg('Moises Henriques') },
                    { name: 'Sean Abbott', stats: 'Wickets: 21', img: getPlayerImg('Sean Abbott') }
                ]}
            ]
        }
    ]
};

// Rendering Engine
function renderData(sportCategory, containerId) {
    const container = document.getElementById(containerId);
    let html = '';

    sportsData[sportCategory].forEach((league) => {
        html += `
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-dark text-white p-3">
                <h4 class="mb-0 fw-bold">${league.name}</h4>
                <small class="text-white-50">${league.desc}</small>
            </div>
            <div class="card-body p-0">
                <div class="accordion accordion-flush" id="teams-${league.id}">`;

        league.teams.forEach((team) => {
            html += `
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed d-flex align-items-center" type="button" data-bs-toggle="collapse" data-bs-target="#team-${team.id}">
                                <img src="${team.logo}" alt="${team.name} Logo" class="team-logo me-3">
                                <div>
                                    <span class="badge bg-secondary me-2">Rank ${team.rank}</span> 
                                    <span class="fw-bold">${team.name}</span>
                                </div>
                            </button>
                        </h2>
                        <div id="team-${team.id}" class="accordion-collapse collapse">
                            <div class="accordion-body bg-light">
                                <p class="small text-muted mb-3"><i class="fw-bold">Bio:</i> ${team.desc}</p>
                                <div class="row g-3">`;
            
            team.players.forEach(player => {
                html += `
                                    <div class="col-md-6 col-lg-4">
                                        <div class="d-flex align-items-center bg-white p-2 border rounded shadow-sm">
                                            <img src="${player.img}" alt="${player.name}" class="player-img me-3">
                                            <div>
                                                <div class="fw-bold text-dark" style="font-size: 0.9rem;">${player.name}</div>
                                                <div class="text-success small fw-semibold">${player.stats}</div>
                                            </div>
                                        </div>
                                    </div>`;
            });

            html += `           </div>
                            </div>
                        </div>
                    </div>`;
        });

        html += `       </div>
            </div>
        </div>`;
    });

    container.innerHTML = html;
}

// Simulated Real-Time Engine
const tickerUpdates = [
    "🚨 LIVE: Arsenal scores in the 89th minute!",
    "🚨 TRANSFER: Real Madrid preparing bid for new striker.",
    "🚨 LIVE: Jasprit Bumrah takes a hat-trick for Mumbai Indians!",
    "🚨 UPDATE: Player rankings adjusted based on recent match."
];

function realTimeEngine() {
    // Update Clock
    document.getElementById('lastUpdated').innerText = `Synced: ${new Date().toLocaleTimeString()}`;
    
    // Update Ticker Randomly
    const randomTicker = tickerUpdates[Math.floor(Math.random() * tickerUpdates.length)];
    document.getElementById('liveTicker').innerText = randomTicker;

    // In a real app, this is where you would call an API like:
    // fetch('https://api-football-v1.p.rapidapi.com/v3/fixtures/live')
    //   .then(response => response.json())
    //   .then(data => updateUI(data));
}

// Initialize Site
renderData('football', 'football-container');
renderData('cricket', 'cricket-container');

// Start Real-Time Engine (Runs every 5 seconds)
setInterval(realTimeEngine, 5000);
realTimeEngine();